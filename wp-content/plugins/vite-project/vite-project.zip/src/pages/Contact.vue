<script setup>
import Heading from "../components/Heading.vue";
</script>
<template>
  <Heading title="Contact" />
</template>
