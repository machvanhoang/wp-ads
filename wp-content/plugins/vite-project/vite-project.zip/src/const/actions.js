// SOCIAL
export const ACTION_GET_SOCIAL = 'get_social';
export const ACTION_SAVE_SOCIAL = 'save_social';
// CONFIGS
export const ACTION_GET_CONFIGS = 'get_configs';
export const ACTION_SAVE_CONFIGS = 'save_configs';